clear all
close all
clc

% % % % % % % % % % % % % % % % DOCUMENTATION % % % % % % % % % % % % % % %
%
%   Cette fonction prend en entr�e un son en format WAV ou MP4 et le 
%   transforme en un format normalis� et mono compatible avec le lecteur
%   MP3 de Seeedstudio. Voici les d�tails : 
%    - Extration de donn�es et de la fr�quence d'�chantillonnage
%    - Conversion de st�r�o � mono
%    - Changement de la fr�quence d'�chantillonage
%    - Ajustement de la plage dynamique
%    - �criture du fichier en format WAV et MP4
%
%   UTILISATION : 
%   Vous devez remplacer les noms de fichiers suivants :
%
%   Fichier d'entr�e  : Original_file_name.mp3 ou Original_file_name.wav
%   Fichier de sortie : New_file_name.wav ET New_file_name.mp3
%
% % % % % % % % % % % % % % % % DOCUMENTATION % % % % % % % % % % % % % % %

% Fr�quence d'�chantillonage d�sir�
Fs_sortie = 48000;

% Lit le fichier et initialise les variables (y=data et Fs=fr�quence d'�chantillonnage)
[y, Fs_entree] = audioread('Original_file_name.mp3 ou Original_file_name.wav');

% Converstisseur de st�r�o � mono
y = y(:,1);

% changement de la fr�quence d'�chantillonage
y = resample(y,Fs_sortie,Fs_entree);

% Ajuste la plage dynamique du son (normalisation)
y = y - mean(y);
AmplitudeMax = max(abs(y));
y = y/AmplitudeMax * 0.95;

% �crit le fichier � partir des variables extraites
audiowrite('New_file_name.wav',y,Fs_sortie);
audiowrite('New_file_name.mp4',y,Fs_sortie);
